<?php
include 'koneksi.php';

// Create Logic
if (isset($_POST['tambah'])) {
    $stmt = mysqli_prepare($conn, "INSERT INTO produk (nama_produk, kategori, harga, stok, keterangan) VALUES (?, ?, ?, ?, ?)");
    mysqli_stmt_bind_param($stmt, "ssiis", $_POST['nama'], $_POST['kategori'], $_POST['harga'], $_POST['stok'], $_POST['keterangan']);
    
    if (mysqli_stmt_execute($stmt)) {
        header("Location: index.php?status=success");
    } else {
        echo "Error: " . mysqli_stmt_error($stmt);
    }
}

// Delete Logic
if (isset($_GET['hapus'])) {
    $stmt = mysqli_prepare($conn, "DELETE FROM produk WHERE id = ?");
    mysqli_stmt_bind_param($stmt, "i", $_GET['hapus']);
    
    if (mysqli_stmt_execute($stmt)) {
        header("Location: index.php?status=deleted");
    }
}
?>