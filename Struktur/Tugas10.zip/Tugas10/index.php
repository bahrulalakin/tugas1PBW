<?php include 'koneksi.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Madinah Jaya Snack</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            font-family: 'Inter', sans-serif;
        }

        .card {
            border: none;
            border-radius: 12px;
            transition: 0.3s;
        }

        .table thead {
            background-color: #f1f3f5;
        }

        .btn-primary {
            background-color: #2b2d42;
            border: none;
        }

        .btn-primary:hover {
            background-color: #1d1e2c;
        }

        .badge-stock {
            font-weight: 500;
            padding: 0.5em 0.8em;
        }
    </style>
</head>

<body>

    <div class="container py-5">
        <div class="row mb-4 align-items-center">
            <div class="col-md-6">
                <h4 class="fw-bold m-0">Pembelian Snack</h4>
                <p class="text-muted small">Madinah Jaya Snack</p>
            </div>
            <div class="col-md-6 text-md-end">
                <a href="tambah.php" class="btn btn-primary px-4 shadow-sm">+ New Product</a>
            </div>
        </div>

        <div class="card shadow-sm">
            <div class="card-body p-4">
                <form method="GET" class="mb-4">
                    <div class="input-group" style="max-width: 400px;">
                        <input type="text" name="cari" class="form-control" placeholder="Search by name..." value="<?= $_GET['cari'] ?? '' ?>">
                        <button class="btn btn-outline-secondary" type="submit">Filter</button>
                    </div>
                </form>

                <div class="table-responsive">
                    <table class="table align-middle">
                        <thead>
                            <tr class="text-secondary small text-uppercase">
                                <th class="py-3">Product Name</th>
                                <th class="py-3">Category</th>
                                <th class="py-3">Price</th>
                                <th class="py-3 text-center">Stock</th>
                                <th class="py-3 text-end">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $search = isset($_GET['cari']) ? "%" . $_GET['cari'] . "%" : "%";
                            $stmt = mysqli_prepare($conn, "SELECT * FROM produk WHERE nama_produk LIKE ? ORDER BY id DESC");
                            mysqli_stmt_bind_param($stmt, "s", $search);
                            mysqli_stmt_execute($stmt);
                            $result = mysqli_stmt_get_result($stmt);

                            while ($row = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td class="fw-semibold"><?= htmlspecialchars($row['nama_produk']) ?></td>
                                    <td><span class="text-muted"><?= htmlspecialchars($row['kategori']) ?></span></td>
                                    <td>Rp<?= number_format($row['harga'], 0, ',', '.') ?></td>
                                    <td class="text-center">
                                        <span class="badge bg-light text-dark border badge-stock"><?= $row['stok'] ?> unit</span>
                                    </td>
                                    <td class="text-end">
                                        <a href="proses.php?hapus=<?= $row['id'] ?>"
                                            class="btn btn-link text-danger btn-sm p-0 text-decoration-none fw-medium"
                                            onclick="return confirm('Delete this item?')">Delete</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</body>

</html>